
const app = document.getElementById("app");
const audio = document.getElementById("startup-sound");
let currentProfile = null;

function playStartup() {
    if (audio) audio.play();
}

function showSplash() {
    app.innerHTML = '<div class="logo fade">8Bit Play</div>';
    playStartup();
    setTimeout(() => {
        showLoading(() => showProfileSelection());
    }, 3000);
}

function showLoading(callback) {
    app.innerHTML = '<div class="fade" style="text-align:center; margin-top:40vh;">Cargando...</div>';
    setTimeout(callback, 2000);
}

function showProfileSelection() {
    const profiles = ['gaelprofile', 'jasonprofile', 'bryanprofile', 'danielprofile'];
    app.innerHTML = '<div class="fade" style="text-align:center;"><h2>Selecciona un perfil</h2>' +
        profiles.map(p => `<img src="images/${p}.png" class="profile-pic" onclick="selectProfile('${p}')">`).join("") + '</div>';
}

function selectProfile(profile) {
    currentProfile = profile;
    showLoading(() => showMainMenu());
}

function showMainMenu() {
    const profileDisplay = `<div id="profile-name">${currentProfile}</div>`;
    const sidebar = `
        <div class="menu-toggle" onclick="toggleSidebar()">☰</div>
        <div class="sidebar" id="sidebar">
            <div onclick="showMainMenu()">Inicio</div>
            <div onclick="showSeries()">Series</div>
            <div onclick="showMovies()">Películas</div>
            <div onclick="showTrends()">Tendencias</div>
            <div onclick="showNew()">Nuevos lanzamientos</div>
            <div onclick="showProfileSelection()">Seleccionar perfil</div>
            <div onclick="showLogin()">Cerrar sesión</div>
        </div>`;
    const content = `
        <div class="fade" style="text-align:center; margin-top: 10vh;">
            <h2>8Bit Crew: La Serie</h2>
            <img src="images/seriecover.jpg" style="width:200px;" onclick="showSerieDetails()">
            <h2>8Bit Crew: La película</h2>
            <img src="images/moviecover.jpg" style="width:200px;" onclick="showMovieDetails()">
        </div>`;
    app.innerHTML = sidebar + profileDisplay + content + '<div class="spam-name">8Bit Play</div>';
}

function toggleSidebar() {
    document.getElementById("sidebar").classList.toggle("active");
}

function showSerieDetails() {
    app.innerHTML = `
        <div class="fade" style="text-align:center;">
            <img src="images/seriebanner.jpg" style="width:100%; filter: brightness(0.3);"><br>
            <h2>8Bit Crew: La Serie</h2>
            <a href="https://youtube.com" target="_blank">Reproducir Capítulo 1</a><br>
            <a href="https://youtube.com" target="_blank">Seleccionar capítulo</a><br>
            <button onclick="showMainMenu()">Volver al menú</button>
        </div>`;
}

function showMovieDetails() {
    app.innerHTML = `
        <div class="fade" style="text-align:center;">
            <img src="images/moviebanner.jpg" style="width:100%; filter: brightness(0.3);"><br>
            <h2>8Bit Crew: La película</h2>
            <a href="https://youtube.com" target="_blank">Ver película</a><br>
            <button onclick="showMainMenu()">Volver al menú</button>
        </div>`;
}

function showTrends() { showMainMenu(); }
function showNew() { showMainMenu(); }
function showSeries() { showSerieDetails(); }
function showMovies() { showMovieDetails(); }
function showLogin() {
    app.innerHTML = `
        <div class="fade" style="text-align:center; margin-top:20vh;">
            <h2>Iniciar sesión</h2>
            <input type="email" placeholder="Correo" value="8bitcrewcuentafake@gmail.com"><br>
            <input type="password" placeholder="Contraseña" value="8btest"><br>
            <button onclick="showSplash()">Entrar</button>
        </div>`;
}

showSplash();
